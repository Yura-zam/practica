<template>
  <div id="app">
    <AppHeader /> <!-- Логотип та заголовок -->
    <main>
      <AboutPage /> <!-- Опис компанії та послуги -->
    </main>
  </div>
</template>

<script>
import AppHeader from './components/AppHeader.vue';
import AboutPage from './components/About.vue'; // Імпорт About компонента

export default {
  name: 'App',
  components: {
    AppHeader,
    AboutPage
  }
};
</script>

<style>
body {
  background-color: #f0f0f0; /* Сірий фон */
  background-image: url('@/assets/Fon.jpg'); /* Фон з зображення */
  background-size: cover; /* Покриває весь екран */
  background-position: center; /* Центрує фон */
}

</style>
