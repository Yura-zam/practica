<template>
  <header>
    <nav>
      <img src="@/assets/logo.jpeg" alt="Old Man's Wheel Logo" class="logo" />
      <h1>Old Man's Wheel</h1>
    </nav>
  </header>
</template>

<script>
export default {
  name: 'AppHeader',
};
</script>

<style>
/* CSS для заголовка */
header {
 
  color: white;
  padding: 10px;
  text-align: center;
}

nav h1 {
  margin: 0;
}

.logo {
  width: 150px;
  height: auto;
}
</style>
